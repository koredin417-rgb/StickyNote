"""Small Windows helpers (ctypes only). Every function is a harmless no-op elsewhere."""
from __future__ import annotations

import ctypes
import gc
import sys

IS_WINDOWS = sys.platform == "win32"

GWL_EXSTYLE = -20
GWLP_HWNDPARENT = -8
WS_EX_APPWINDOW = 0x00040000
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_TRANSPARENT = 0x00000020
WS_EX_LAYERED = 0x00080000
DWMWA_TRANSITIONS_FORCEDISABLED = 3
WM_SYSCOMMAND = 0x0112
SC_MINIMIZE, SC_RESTORE = 0xF020, 0xF120
SW_MINIMIZE = 6
SW_RESTORE = 9
ERROR_ALREADY_EXISTS = 183
SYNCHRONIZE = 0x00100000
SM_XVIRTUALSCREEN, SM_YVIRTUALSCREEN = 76, 77
SM_CXVIRTUALSCREEN, SM_CYVIRTUALSCREEN = 78, 79
SM_CXSCREEN, SM_CYSCREEN = 0, 1
MONITORINFOF_PRIMARY = 0x00000001

if IS_WINDOWS:
    from ctypes import wintypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    user32.GetWindowLongW.argtypes = (wintypes.HWND, ctypes.c_int)
    user32.GetWindowLongW.restype = ctypes.c_long
    user32.SetWindowLongW.argtypes = (wintypes.HWND, ctypes.c_int, ctypes.c_long)
    user32.SetWindowLongW.restype = ctypes.c_long
    user32.ShowWindow.argtypes = (wintypes.HWND, ctypes.c_int)
    user32.SetWindowLongPtrW.argtypes = (wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t)
    user32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
    kernel32.CreateMutexW.argtypes = (ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR)
    kernel32.CreateMutexW.restype = wintypes.HANDLE
    kernel32.OpenMutexW.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR)
    kernel32.OpenMutexW.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)


def clip_height(win, width=None, height=None) -> bool:
    """Show only the top ``height`` px of ``win`` (a window region), or all of it again
    (``width`` None). A roll moves this edge instead of resizing the window: nothing is
    laid out or uncovered, so there is nothing to paint late. False where it cannot."""
    hwnd = hwnd_of(win) if IS_WINDOWS else 0
    if not hwnd:
        return False
    gdi32 = ctypes.WinDLL("gdi32")
    gdi32.CreateRectRgn.restype = ctypes.c_void_p
    user32.SetWindowRgn.argtypes = (ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int)
    if width is None:
        return bool(user32.SetWindowRgn(ctypes.c_void_p(hwnd), None, True))
    rgn = gdi32.CreateRectRgn(0, 0, int(width), max(1, int(height)))
    if not rgn:
        return False
    if not user32.SetWindowRgn(ctypes.c_void_p(hwnd), ctypes.c_void_p(rgn), True):
        gdi32.DeleteObject(ctypes.c_void_p(rgn))
        return False
    return True                             # (the window owns the region now)


def paint_now(win):
    """Paint ``win`` now (it just grew): Windows' paint request reaches Tk as window events,
    which are handled here, and Tk draws at once (idle tasks) instead of a frame later, so the
    part just uncovered never shows unpainted."""
    try:
        import _tkinter
        hwnd = hwnd_of(win) if IS_WINDOWS else 0
        if hwnd:
            user32.RedrawWindow(ctypes.c_void_p(hwnd), None, None, 0x0001 | 0x0100 | 0x0080)  # INVALIDATE|UPDATENOW|ALLCHILDREN
        for _ in range(64):                 # (only window events: no timers run in between)
            if not win.tk.dooneevent(_tkinter.WINDOW_EVENTS | _tkinter.DONT_WAIT):
                break
        win.update_idletasks()
    except Exception:
        pass


_snap = None                               # gdi32/user32 prototypes for snapshot(), declared once


def _snapshot_api():
    global _snap
    if _snap is None:
        from ctypes import wintypes
        H = wintypes.HANDLE

        class BIH(ctypes.Structure):
            _fields_ = [("biSize", wintypes.DWORD), ("biWidth", ctypes.c_long), ("biHeight", ctypes.c_long),
                        ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD),
                        ("biCompression", wintypes.DWORD), ("biSizeImage", wintypes.DWORD),
                        ("biXPelsPerMeter", ctypes.c_long), ("biYPelsPerMeter", ctypes.c_long),
                        ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD)]
        g, u = ctypes.WinDLL("gdi32"), ctypes.WinDLL("user32")    # own prototypes, apart from user32 above
        u.GetDC.restype, u.GetDC.argtypes = H, (wintypes.HWND,)
        u.ReleaseDC.argtypes = (wintypes.HWND, H)
        u.GetWindowRect.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.RECT))
        u.PrintWindow.argtypes = (wintypes.HWND, H, wintypes.UINT)
        g.CreateCompatibleDC.restype, g.CreateCompatibleDC.argtypes = H, (H,)
        g.CreateCompatibleBitmap.restype = H
        g.CreateCompatibleBitmap.argtypes = (H, ctypes.c_int, ctypes.c_int)
        g.SelectObject.restype, g.SelectObject.argtypes = H, (H, H)
        g.DeleteObject.argtypes = (H,)
        g.DeleteDC.argtypes = (H,)
        g.GetDIBits.argtypes = (H, H, wintypes.UINT, wintypes.UINT, ctypes.c_void_p,
                                ctypes.POINTER(BIH), wintypes.UINT)
        _snap = (g, u, BIH)
    return _snap


def snapshot(win):
    """What a Tk toplevel shows, drawn by the window itself (PrintWindow, so covered or
    off-screen parts too): (width, height, BGRX buffer), or None. The buffer is the ctypes
    array itself (no copy); Image.frombuffer reads it as it is."""
    hwnd = hwnd_of(win) if IS_WINDOWS else 0
    if not hwnd:
        return None
    from ctypes import wintypes
    gdi32, u32, BIH = _snapshot_api()
    r = wintypes.RECT()
    if not u32.GetWindowRect(hwnd, ctypes.byref(r)):
        return None
    w, h = r.right - r.left, r.bottom - r.top
    if w <= 0 or h <= 0:
        return None
    hdc = u32.GetDC(None)
    mdc = gdi32.CreateCompatibleDC(hdc)
    bmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
    old = gdi32.SelectObject(mdc, bmp)
    try:
        if not u32.PrintWindow(hwnd, mdc, 2):               # PW_RENDERFULLCONTENT
            return None
        bih = BIH(biSize=ctypes.sizeof(BIH), biWidth=w, biHeight=-h, biPlanes=1, biBitCount=32)
        buf = ctypes.create_string_buffer(w * h * 4)
        if not gdi32.GetDIBits(mdc, bmp, 0, h, buf, ctypes.byref(bih), 0):
            return None
        return w, h, buf
    finally:
        if old:
            gdi32.SelectObject(mdc, old)                    # the bitmap out of the DC before it is deleted
        gdi32.DeleteObject(bmp)
        gdi32.DeleteDC(mdc)
        u32.ReleaseDC(None, hdc)


def fine_timer(on: bool) -> bool:
    """Ask Windows for 1 ms timer ticks (``on``) or give them back. Tk's ``after`` otherwise
    waits in 15.6 ms steps, so an animation's frames come at 16 or 31 ms, unevenly. Since
    Windows 10 2004 this only affects this process. Returns whether it is on now."""
    if not IS_WINDOWS:
        return False
    try:
        winmm = ctypes.WinDLL("winmm")
        if on:
            return winmm.timeBeginPeriod(1) == 0      # TIMERR_NOERROR
        winmm.timeEndPeriod(1)
    except (OSError, AttributeError):
        pass
    return False


def hwnd_of(win) -> int:
    """Outer (frame) window handle of a Tk toplevel, 0 if it does not exist yet."""
    try:
        return int(win.wm_frame(), 16)
    except Exception:
        return 0


def show_in_taskbar(win) -> bool:
    """Give a borderless (overrideredirect) window a taskbar button.

    Returns True when the style was changed; the window must then be hidden
    and shown again for the taskbar to notice.
    """
    hwnd = hwnd_of(win)
    if not IS_WINDOWS or not hwnd:
        return False
    ex = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
    wanted = (ex & ~WS_EX_TOOLWINDOW) | WS_EX_APPWINDOW
    if wanted == ex:
        return False
    user32.SetWindowLongW(hwnd, GWL_EXSTYLE, wanted)
    return True


def set_owner(win, owner) -> None:
    """Make ``owner`` own ``win``: it then stays above the owner, comes forward
    with it and hides with it. (Tk's ``transient`` does not do this for
    borderless windows.)"""
    hwnd, owner_hwnd = hwnd_of(win), hwnd_of(owner)
    if IS_WINDOWS and hwnd and owner_hwnd:
        user32.SetWindowLongPtrW(hwnd, GWLP_HWNDPARENT, owner_hwnd)


def is_iconic(win) -> bool:
    """Whether Windows has ``win`` minimized (also when Tk was not told)."""
    hwnd = hwnd_of(win)
    return bool(IS_WINDOWS and hwnd and user32.IsIconic(hwnd))


def minimize(win, raw: bool = False) -> None:
    """Minimize ``win``. This calls ShowWindow, which sends no WM_SYSCOMMAND, so it never
    reaches hook_syscommand's swallowing: ``raw`` only states that intent (the same either way)."""
    hwnd = hwnd_of(win)
    if IS_WINDOWS and hwnd:
        user32.ShowWindow(hwnd, SW_MINIMIZE)
    else:
        win.iconify()


def restore(win, raw: bool = False) -> None:
    """Restore ``win`` (see minimize for ``raw``)."""
    hwnd = hwnd_of(win)
    if IS_WINDOWS and hwnd:
        user32.ShowWindow(hwnd, SW_RESTORE)
    else:
        win.deiconify()


def set_click_through(win, on: bool) -> None:
    """Mouse clicks pass through ``win`` to what is under it (on), or hit it again (off).
    Call after the window is first mapped.

    On adds WS_EX_TRANSPARENT | WS_EX_LAYERED; off clears only WS_EX_TRANSPARENT. Rule for every
    click-through window (decided with motion.Outlines; HolidayCard and the preview follow it):
    Tk must own the layering. Give the window ``-alpha`` below 1.0 (motion.CLICK_THROUGH_ALPHA,
    0.999, looks opaque) before turning this on, and keep it below 1.0 for as long as it is
    click-through (a ``-transparentcolor`` window is layered by Tk as well). Then Tk has called
    SetLayeredWindowAttributes itself, so the window draws, and its later ``-alpha`` changes
    (fades) keep both bits. On a window Tk has not layered, Tk's first ``-alpha`` change below
    1.0 writes its own style back and drops WS_EX_TRANSPARENT (seen with Tk 9), which calling
    SetLayeredWindowAttributes here would not prevent; so this function does not call it."""
    hwnd = hwnd_of(win)
    if not IS_WINDOWS or not hwnd:
        return
    ex = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
    wanted = (ex | WS_EX_TRANSPARENT | WS_EX_LAYERED) if on else (ex & ~WS_EX_TRANSPARENT)
    if wanted != ex:
        user32.SetWindowLongW(hwnd, GWL_EXSTYLE, wanted)


def disable_transitions(win) -> None:
    """Turn off Windows' own minimize/restore animation for ``win`` (the app animates itself).
    Ignored when DWM is unavailable."""
    hwnd = hwnd_of(win)
    if not IS_WINDOWS or not hwnd:
        return
    try:
        value = ctypes.c_int(1)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            wintypes.HWND(hwnd), DWMWA_TRANSITIONS_FORCEDISABLED, ctypes.byref(value), ctypes.sizeof(value))
    except Exception:
        pass


DWMWA_WINDOW_CORNER_PREFERENCE, DWMWCP_ROUND = 33, 2
_can_round: bool | None = None


def can_round() -> bool:
    """Windows 11 (build 22000 on): DWM rounds a window's corners and gives it a shadow, layered
    or not (spike S1). Windows 10 ignores the attribute: the app keeps its 1 px border there."""
    global _can_round
    if _can_round is None:
        try:
            _can_round = IS_WINDOWS and sys.getwindowsversion().build >= 22000
        except Exception:
            _can_round = False
    return _can_round


def round_corners(win) -> bool:
    """Ask DWM for rounded corners (and with them its shadow) on ``win``'s frame window. False
    when it cannot (not Windows 11, no frame window yet, or DWM said no)."""
    hwnd = hwnd_of(win)
    try:
        framed = hwnd and hwnd != win.winfo_id()    # (before its first map Tk has no frame window)
    except Exception:
        framed = False
    if not can_round() or not framed:
        return False
    try:
        value = ctypes.c_int(DWMWCP_ROUND)
        return ctypes.windll.dwmapi.DwmSetWindowAttribute(
            wintypes.HWND(hwnd), DWMWA_WINDOW_CORNER_PREFERENCE, ctypes.byref(value), ctypes.sizeof(value)) == 0
    except Exception:
        return False


DWMWA_FORCE_ICONIC_REPRESENTATION = 7
DWMWA_HAS_ICONIC_BITMAP = 10
DWMWA_DISALLOW_PEEK = 11
WM_DWMSENDICONICTHUMBNAIL = 0x0323


def use_iconic_thumbnail(win, on: bool = True) -> bool:
    """The taskbar preview of ``win`` is a picture the app draws (set_iconic_thumbnail, when
    DWM asks: WM_DWMSENDICONICTHUMBNAIL, see hook_syscommand), not the window itself; no Aero
    Peek of it either. ``on=False`` gives the plain preview back. Returns whether DWM took it."""
    hwnd = hwnd_of(win)
    if not IS_WINDOWS or not hwnd:
        return False
    try:
        dwm = ctypes.windll.dwmapi
        ok = True
        for attr in (DWMWA_FORCE_ICONIC_REPRESENTATION, DWMWA_HAS_ICONIC_BITMAP, DWMWA_DISALLOW_PEEK):
            value = ctypes.c_int(1 if on else 0)
            ok &= dwm.DwmSetWindowAttribute(wintypes.HWND(hwnd), attr, ctypes.byref(value),
                                            ctypes.sizeof(value)) == 0
        return ok
    except Exception:
        return False


def set_iconic_thumbnail(win, image) -> int:
    """Give DWM ``image`` (a PIL RGBA image, no bigger than it asked for) as the taskbar preview
    of ``win``. Returns the HRESULT: 0 when DWM took it (-1: no call was made)."""
    hwnd = hwnd_of(win)
    if not IS_WINDOWS or not hwnd:
        return -1
    gdi32 = ctypes.WinDLL("gdi32")
    H = wintypes.HANDLE

    class BIH(ctypes.Structure):
        _fields_ = [("biSize", wintypes.DWORD), ("biWidth", ctypes.c_long), ("biHeight", ctypes.c_long),
                    ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD),
                    ("biCompression", wintypes.DWORD), ("biSizeImage", wintypes.DWORD),
                    ("biXPelsPerMeter", ctypes.c_long), ("biYPelsPerMeter", ctypes.c_long),
                    ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD)]
    gdi32.CreateDIBSection.restype = H
    gdi32.CreateDIBSection.argtypes = (H, ctypes.POINTER(BIH), wintypes.UINT, ctypes.POINTER(ctypes.c_void_p),
                                       H, wintypes.DWORD)
    gdi32.DeleteObject.argtypes = (H,)
    w, h = image.size
    # premultiplied BGRA, top-down
    r, g, b, a = image.convert("RGBA").split()
    from PIL import Image, ImageChops
    r, g, b = (ImageChops.multiply(c, a) for c in (r, g, b))
    raw = Image.merge("RGBA", (b, g, r, a)).tobytes()
    bih = BIH(biSize=ctypes.sizeof(BIH), biWidth=w, biHeight=-h, biPlanes=1, biBitCount=32)
    bits = ctypes.c_void_p()
    bmp = gdi32.CreateDIBSection(None, ctypes.byref(bih), 0, ctypes.byref(bits), None, 0)
    if not bmp:
        return -1
    try:
        ctypes.memmove(bits, raw, len(raw))
        dwm = ctypes.windll.dwmapi
        dwm.DwmSetIconicThumbnail.argtypes = (wintypes.HWND, H, wintypes.DWORD)
        return dwm.DwmSetIconicThumbnail(hwnd, bmp, 0) & 0xFFFFFFFF
    except Exception:
        return -1
    finally:
        gdi32.DeleteObject(bmp)


def invalidate_iconic(win) -> None:
    """The taskbar preview is out of date: DWM asks for a new one when it next shows it."""
    hwnd = hwnd_of(win)
    if IS_WINDOWS and hwnd:
        try:
            ctypes.windll.dwmapi.DwmInvalidateIconicBitmaps(wintypes.HWND(hwnd))
        except Exception:
            pass


def virtual_screen() -> tuple[int, int, int, int] | None:
    """(x, y, width, height) covering all monitors."""
    if not IS_WINDOWS:
        return None
    m = user32.GetSystemMetrics
    box = (m(SM_XVIRTUALSCREEN), m(SM_YVIRTUALSCREEN),
           m(SM_CXVIRTUALSCREEN), m(SM_CYVIRTUALSCREEN))
    return box if box[2] > 0 and box[3] > 0 else None


def work_area(win) -> tuple[int, int, int, int] | None:
    """(left, top, right, bottom) of the usable part (without the taskbar) of the monitor
    that ``win`` is on."""
    hwnd = hwnd_of(win)
    if not IS_WINDOWS or not hwnd:
        return None

    class MONITORINFO(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
                    ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]
    try:
        user32.MonitorFromWindow.argtypes = (wintypes.HWND, wintypes.DWORD)
        user32.MonitorFromWindow.restype = wintypes.HANDLE
        user32.GetMonitorInfoW.argtypes = (wintypes.HANDLE, ctypes.c_void_p)
        monitor = user32.MonitorFromWindow(hwnd, 2)         # MONITOR_DEFAULTTONEAREST
        info = MONITORINFO()
        info.cbSize = ctypes.sizeof(MONITORINFO)
        if not monitor or not user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
            return None
        r = info.rcWork
        return r.left, r.top, r.right, r.bottom
    except Exception:
        return None


def _enum_monitors() -> list[tuple[bool, tuple[int, int, int, int], tuple[int, int, int, int]]]:
    """(is primary, monitor, work area) of every monitor, each (left, top, right, bottom),
    in Windows' order. [] when Windows cannot list them."""
    if not IS_WINDOWS:
        return []

    class MONITORINFO(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
                    ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]
    found = []
    proc_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HANDLE, wintypes.HDC,
                                   ctypes.POINTER(wintypes.RECT), wintypes.LPARAM)

    def each(monitor, _hdc, _rect, _data):
        info = MONITORINFO()
        info.cbSize = ctypes.sizeof(MONITORINFO)
        if user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
            m, w = info.rcMonitor, info.rcWork
            found.append((bool(info.dwFlags & MONITORINFOF_PRIMARY),
                          (m.left, m.top, m.right, m.bottom), (w.left, w.top, w.right, w.bottom)))
        return True
    try:
        user32.GetMonitorInfoW.argtypes = (wintypes.HANDLE, ctypes.c_void_p)
        user32.EnumDisplayMonitors.argtypes = (wintypes.HDC, ctypes.c_void_p, proc_type, wintypes.LPARAM)
        user32.EnumDisplayMonitors(None, None, proc_type(each), 0)
    except Exception:
        return []
    return found


def work_areas() -> list[tuple[int, int, int, int]]:
    """(left, top, right, bottom) of the usable part of every monitor."""
    return [work for _primary, _monitor, work in _enum_monitors()]


def monitors() -> list[tuple[tuple[int, int, int, int], tuple[int, int, int, int]]]:
    """(monitor, work area) of every monitor, each (left, top, right, bottom), the primary
    one first. If Windows lists none: the primary screen's size for both."""
    if not IS_WINDOWS:
        return []
    found = _enum_monitors()
    if not found:
        screen = (0, 0, user32.GetSystemMetrics(SM_CXSCREEN), user32.GetSystemMetrics(SM_CYSCREEN))
        return [(screen, screen)]
    found.sort(key=lambda f: not f[0])      # the primary first, the rest in Windows' order
    return [(monitor, work) for _primary, monitor, work in found]


def set_dpi_aware() -> None:
    if not IS_WINDOWS:
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # per-monitor
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def set_app_id(app_id: str) -> None:
    """Group our windows under our own taskbar icon (not python.exe's)."""
    if not IS_WINDOWS:
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except Exception:
        pass


def acquire_single_instance(name: str):
    """Return a mutex handle if we are the first instance, else None.

    Keep the returned handle alive for the life of the process.
    """
    if not IS_WINDOWS:
        return object()
    handle = kernel32.CreateMutexW(None, False, name)
    if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
        return None
    return handle


def load_private_fonts(folder) -> int:
    """Make the font files in ``folder`` usable by this program only (nothing is installed
    in Windows). Returns how many were loaded."""
    if not IS_WINDOWS:
        return 0
    from pathlib import Path
    add = ctypes.windll.gdi32.AddFontResourceExW
    add.argtypes = (wintypes.LPCWSTR, wintypes.DWORD, ctypes.c_void_p)
    loaded = 0
    for path in sorted(Path(folder).glob("*.[ot]tf")):
        loaded += bool(add(str(path), 0x10, None))         # FR_PRIVATE
    return loaded


def is_admin() -> bool:
    """True when this process runs with administrator rights (elevated)."""
    if not IS_WINDOWS:
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def instance_running(name: str) -> bool:
    """True while some process holds the single-instance mutex ``name``."""
    if not IS_WINDOWS:
        return False
    handle = kernel32.OpenMutexW(SYNCHRONIZE, False, name)
    if not handle:
        return False
    kernel32.CloseHandle(handle)
    return True


# ---- IME (Korean input) --------------------------------------------------------
# A Korean syllable is put together in the IME ("composition") before it reaches the
# text. Tk loses it when the user clicks elsewhere first, so the app finishes it itself.
GCS_COMPSTR = 0x0008
NI_COMPOSITIONSTR = 0x0015
CPS_COMPLETE, CPS_CANCEL = 0x0001, 0x0004
WM_KILLFOCUS, WM_NCDESTROY, WM_IME_SETCONTEXT = 0x0008, 0x0082, 0x0281
ISC_SHOWUICOMPOSITIONWINDOW = 0x80000000
ISC_SHOWUIALL = 0xC000000F

if IS_WINDOWS:
    imm32 = ctypes.WinDLL("imm32")
    comctl32 = ctypes.WinDLL("comctl32")
    _HIMC = wintypes.HANDLE
    imm32.ImmGetContext.argtypes = (wintypes.HWND,)
    imm32.ImmGetContext.restype = _HIMC
    imm32.ImmReleaseContext.argtypes = (wintypes.HWND, _HIMC)
    imm32.ImmGetCompositionStringW.argtypes = (_HIMC, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD)
    imm32.ImmGetCompositionStringW.restype = ctypes.c_long
    imm32.ImmNotifyIME.argtypes = (_HIMC, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD)
    _SUBCLASSPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                                       wintypes.LPARAM, ctypes.c_size_t, ctypes.c_size_t)
    comctl32.SetWindowSubclass.argtypes = (wintypes.HWND, _SUBCLASSPROC, ctypes.c_size_t, ctypes.c_size_t)
    comctl32.RemoveWindowSubclass.argtypes = (wintypes.HWND, _SUBCLASSPROC, ctypes.c_size_t)
    comctl32.DefSubclassProc.argtypes = (wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
    comctl32.DefSubclassProc.restype = ctypes.c_ssize_t

_focus_hooks: dict = {}


# ---- Python window procs and the garbage collector ------------------------------
# hook_ime and hook_syscommand put Python code (ctypes callbacks) into a Tk window's message
# handling. Tk's event loop calls them from inside DispatchMessage, with _tkinter's saved
# thread state set for that loop. Any tkinter call made in there resets that state to NULL on
# its way out (LEAVE_TCL), and the next Python callback of the same update()/mainloop step
# aborts the process: "Fatal Python error: PyEval_RestoreThread ... thread state is NULL".
# The procs make no tkinter call themselves, but a cyclic garbage collection landing in one
# runs finalizers that do (tkinter.font.Font, tkinter.Image, PIL.ImageTk.PhotoImage and
# tkinter.Variable delete their Tcl side in __del__). So once a proc is in, Python collects
# no garbage by itself: the app calls collect_garbage() from a Tk ``after`` job instead.
def _keep_gc_out_of_procs() -> None:
    gc.disable()


def collect_garbage() -> None:
    """The collection Python would run by itself now (the oldest generation past its
    threshold), if any. Call it from a Tk callback (an ``after`` job), never from a proc."""
    counts, limits = gc.get_count(), gc.get_threshold()
    if not limits[0]:
        return                              # collection was turned off (threshold 0)
    gen = next((g for g in (2, 1, 0) if counts[g] > limits[g]), None)
    if gen is not None:
        gc.collect(gen)


def _notify_ime(hwnd, action) -> None:
    himc = imm32.ImmGetContext(hwnd)
    if himc:
        imm32.ImmNotifyIME(himc, NI_COMPOSITIONSTR, action, 0)
        imm32.ImmReleaseContext(hwnd, himc)


def composition(hwnd: int, take: bool = False) -> str:
    """The syllable the IME is still putting together for ``hwnd``'s thread ("" when
    nothing is being composed). ``take`` also takes it out of the IME, which then forgets it."""
    if not IS_WINDOWS or not hwnd:
        return ""
    himc = imm32.ImmGetContext(hwnd)
    if not himc:
        return ""
    try:
        size = imm32.ImmGetCompositionStringW(himc, GCS_COMPSTR, None, 0)
        if size <= 0:
            return ""
        buf = ctypes.create_unicode_buffer(size // 2 + 1)
        imm32.ImmGetCompositionStringW(himc, GCS_COMPSTR, buf, size)
        if take:
            imm32.ImmNotifyIME(himc, NI_COMPOSITIONSTR, CPS_CANCEL, 0)
        return buf.value
    finally:
        imm32.ImmReleaseContext(hwnd, himc)


def hide_ime_box(hwnd: int) -> None:
    """Tell the IME once more not to draw its own box for the syllable being typed (see
    hook_ime). It only hears this when its window gets the focus from Windows; a focus
    change inside the app (or a moment the hook missed) could leave the white box on."""
    if not IS_WINDOWS or not hwnd or not hook_ime(hwnd):
        return
    send = user32.SendMessageW
    send.argtypes = (wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
    send(hwnd, WM_IME_SETCONTEXT, 1, ISC_SHOWUIALL & ~ISC_SHOWUICOMPOSITIONWINDOW)


def take_composition(hwnd: int) -> str:
    return composition(hwnd, take=True)


def hook_ime(hwnd: int) -> bool:
    """Korean input for the window ``hwnd`` (a Tk toplevel's own window):

    * When it loses the keyboard focus, finish the IME's syllable first. Tk handles the
      focus loss before the IME's last character and then throws that character away;
      finished first, it arrives in time.
    * The IME does not draw its own (white) box for the syllable being typed: the app
      shows it in the text itself (NoteWindow._show_preedit).

    Its proc is Python run inside Tk's window proc: hooked, Python collects no garbage by
    itself (see collect_garbage)."""
    if not IS_WINDOWS or not hwnd:
        return False
    if hwnd in _focus_hooks:
        return True

    @_SUBCLASSPROC
    def proc(h, msg, wparam, lparam, uid, _data):
        try:
            if msg == WM_KILLFOCUS:
                _notify_ime(h, CPS_COMPLETE)
            elif msg == WM_IME_SETCONTEXT:
                lparam &= ~ISC_SHOWUICOMPOSITIONWINDOW
            elif msg == WM_NCDESTROY:
                comctl32.RemoveWindowSubclass(h, proc, uid)
                _focus_hooks.pop(h, None)
        except Exception:
            pass
        return comctl32.DefSubclassProc(h, msg, wparam, lparam)

    if not comctl32.SetWindowSubclass(hwnd, proc, 1, 0):
        return False
    _focus_hooks[hwnd] = proc           # keep the callback alive while the window lives
    _keep_gc_out_of_procs()
    return True


_syscmd_hooks: dict = {}


WM_SIZE, SIZE_MINIMIZED, WM_WINDOWPOSCHANGED = 0x0005, 1, 0x0047
WM_DISPLAYCHANGE, WM_SETTINGCHANGE, WM_DPICHANGED = 0x007E, 0x001A, 0x02E0
WM_TIMECHANGE, WM_POWERBROADCAST = 0x001E, 0x0218
PBT_APMRESUMESUSPEND, PBT_APMRESUMEAUTOMATIC = 0x0007, 0x0012


def hook_syscommand(win, sink: list, wake=None) -> None:
    """Swallow the system's minimize and restore of ``win`` (the taskbar button, Win+D...) and
    append ("min" | "restore", hwnd, time.monotonic()) to ``sink`` instead; the app does the
    animation itself. Other messages go on as before. The proc only appends to the list: it
    never calls tkinter (a Tcl thread-state hazard). ``wake()`` (a Waker's ping: a socket send,
    no tkinter) then has the app drain ``sink``. Also queued, without swallowing them: a minimize
    by other means (WM_WINDOWPOSCHANGED, iconic), the monitors or the work area changing ("screens"), the clock
    changing or the computer waking up ("day"). The subclass (uid 2, beside hook_ime's uid 1)
    removes itself on WM_NCDESTROY.
    Like hook_ime, it turns Python's own garbage collection off (see collect_garbage)."""
    hwnd = hwnd_of(win)
    if not IS_WINDOWS or not hwnd or hwnd in _syscmd_hooks:
        return
    import time

    def queued(entry, swallow=True):
        sink.append(entry)
        if wake is not None:
            wake()
        return 0 if swallow else None

    @_SUBCLASSPROC
    def proc(h, msg, wparam, lparam, uid, _data):
        try:
            if msg == WM_SYSCOMMAND:
                command = wparam & 0xFFF0
                if command == SC_MINIMIZE:
                    return queued(("min", h, time.monotonic()))
                if command == SC_RESTORE:
                    return queued(("restore", h, time.monotonic()))
            elif msg == WM_DWMSENDICONICTHUMBNAIL:     # the taskbar preview: the app draws it (later)
                return queued(("thumb", h, ((lparam >> 16) & 0xFFFF, lparam & 0xFFFF)))
            elif msg == WM_WINDOWPOSCHANGED and user32.IsIconic(h):
                queued(("sized", h, 0), swallow=False)     # minimized another way (Win+M): the drain
                                                           # undoes it for the app (Tk takes WM_SIZE itself)
            elif msg in (WM_DISPLAYCHANGE, WM_SETTINGCHANGE, WM_DPICHANGED):
                queued(("screens", h, 0), swallow=False)
            elif msg == WM_TIMECHANGE or (msg == WM_POWERBROADCAST
                                          and wparam in (PBT_APMRESUMESUSPEND, PBT_APMRESUMEAUTOMATIC)):
                queued(("day", h, 0), swallow=False)
            elif msg == WM_NCDESTROY:
                comctl32.RemoveWindowSubclass(h, proc, uid)
                _syscmd_hooks.pop(h, None)
        except Exception:
            pass
        return comctl32.DefSubclassProc(h, msg, wparam, lparam)

    if comctl32.SetWindowSubclass(hwnd, proc, 2, 0):
        _syscmd_hooks[hwnd] = proc          # keep the callback alive while the window lives
        _keep_gc_out_of_procs()


# ---- measurements (perf.py) ---------------------------------------------------------------
if IS_WINDOWS:
    class _PROCESS_MEMORY_COUNTERS_EX(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                    ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
                    ("PrivateUsage", ctypes.c_size_t)]

    _k32 = ctypes.WinDLL("kernel32")                # own prototypes, apart from the shared handle
    _k32.GetCurrentProcess.restype = wintypes.HANDLE
    _k32.K32GetProcessMemoryInfo.argtypes = (wintypes.HANDLE, ctypes.POINTER(_PROCESS_MEMORY_COUNTERS_EX),
                                             wintypes.DWORD)
    _k32.K32GetProcessMemoryInfo.restype = wintypes.BOOL
    _u32 = ctypes.WinDLL("user32")
    _u32.GetGuiResources.argtypes = (wintypes.HANDLE, wintypes.DWORD)
    _u32.GetGuiResources.restype = wintypes.DWORD


def process_memory() -> int:
    """This process's private bytes (what it alone holds in memory), or 0 off Windows."""
    if not IS_WINDOWS:
        return 0
    c = _PROCESS_MEMORY_COUNTERS_EX()
    c.cb = ctypes.sizeof(c)
    if not _k32.K32GetProcessMemoryInfo(_k32.GetCurrentProcess(), ctypes.byref(c), c.cb):
        return 0
    return int(c.PrivateUsage)


def gui_handles() -> tuple[int, int]:
    """(GDI objects, USER objects) this process holds now, or (0, 0) off Windows."""
    if not IS_WINDOWS:
        return 0, 0
    me = _k32.GetCurrentProcess()
    return int(_u32.GetGuiResources(me, 0)), int(_u32.GetGuiResources(me, 1))


# ---- frame clock (anim.py) ----------------------------------------------------------------
if IS_WINDOWS:
    _U32_, _U64_ = ctypes.c_uint32, ctypes.c_uint64

    class _DWM_TIMING_INFO(ctypes.Structure):
        _pack_ = 1                          # dwmapi.h wraps its structs in pshpack1.h
        _fields_ = [("cbSize", _U32_), ("rateRefresh_num", _U32_), ("rateRefresh_den", _U32_),
                    ("qpcRefreshPeriod", _U64_), ("rateCompose_num", _U32_), ("rateCompose_den", _U32_),
                    ("qpcVBlank", _U64_), ("cRefresh", _U64_), ("cDXRefresh", _U32_), ("qpcCompose", _U64_),
                    ("cFrame", _U64_), ("cDXPresent", _U32_), ("cRefreshFrame", _U64_),
                    ("cFrameSubmitted", _U64_), ("cDXPresentSubmitted", _U32_), ("cFrameConfirmed", _U64_),
                    ("cDXPresentConfirmed", _U32_), ("cRefreshConfirmed", _U64_),
                    ("cDXRefreshConfirmed", _U32_), ("cFramesLate", _U64_), ("cFramesOutstanding", _U32_),
                    ("cFrameDisplayed", _U64_), ("qpcFrameDisplayed", _U64_), ("cRefreshFrameDisplayed", _U64_),
                    ("cFrameComplete", _U64_), ("qpcFrameComplete", _U64_), ("cFramePending", _U64_),
                    ("qpcFramePending", _U64_), ("cFramesDisplayed", _U64_), ("cFramesComplete", _U64_),
                    ("cFramesPending", _U64_), ("cFramesAvailable", _U64_), ("cFramesDropped", _U64_),
                    ("cFramesMissed", _U64_), ("cRefreshNextDisplayed", _U64_),
                    ("cRefreshNextPresented", _U64_), ("cRefreshesDisplayed", _U64_),
                    ("cRefreshesPresented", _U64_), ("cRefreshStarted", _U64_), ("cPixelsReceived", _U64_),
                    ("cPixelsDrawn", _U64_), ("cBuffersEmpty", _U64_)]

    _dwm = ctypes.WinDLL("dwmapi")
    _dwm.DwmGetCompositionTimingInfo.argtypes = (wintypes.HWND, ctypes.POINTER(_DWM_TIMING_INFO))
    _dwm.DwmGetCompositionTimingInfo.restype = ctypes.c_long
    _qpf = ctypes.c_int64()
    _k32.QueryPerformanceFrequency(ctypes.byref(_qpf))
    _QPF = float(_qpf.value or 1)

    _u32.BeginDeferWindowPos.argtypes = (ctypes.c_int,)
    _u32.BeginDeferWindowPos.restype = wintypes.HANDLE
    _u32.DeferWindowPos.argtypes = (wintypes.HANDLE, wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_int, ctypes.c_int, wintypes.UINT)
    _u32.DeferWindowPos.restype = wintypes.HANDLE
    _u32.EndDeferWindowPos.argtypes = (wintypes.HANDLE,)
    _u32.EndDeferWindowPos.restype = wintypes.BOOL
    _u32.SystemParametersInfoW.argtypes = (wintypes.UINT, wintypes.UINT, ctypes.c_void_p, wintypes.UINT)
    _u32.SystemParametersInfoW.restype = wintypes.BOOL

_SWP_NOSIZE, _SWP_NOZORDER, _SWP_NOACTIVATE = 0x0001, 0x0004, 0x0010
_SPI_GETCLIENTAREAANIMATION = 0x1042


def composition_timing() -> tuple[float, float] | None:
    """(the last vblank, the refresh period), both in time.perf_counter() seconds (it and the
    performance counter share an epoch), or None when DWM cannot tell."""
    if not IS_WINDOWS:
        return None
    info = _DWM_TIMING_INFO()
    info.cbSize = ctypes.sizeof(info)
    if _dwm.DwmGetCompositionTimingInfo(None, ctypes.byref(info)) != 0 or not info.qpcRefreshPeriod:
        return None
    return info.qpcVBlank / _QPF, info.qpcRefreshPeriod / _QPF


def defer_move(moves) -> bool:
    """Move (and size) several windows in one step: ``moves`` is a list of
    (hwnd, x, y, w, h), w/h None to keep the size. False if Windows refused any of it."""
    if not IS_WINDOWS or not moves:
        return bool(moves) is False
    h = _u32.BeginDeferWindowPos(len(moves))
    if not h:
        return False
    for hwnd, x, y, w, hh in moves:
        flags = _SWP_NOZORDER | _SWP_NOACTIVATE | (_SWP_NOSIZE if w is None or hh is None else 0)
        h = _u32.DeferWindowPos(h, hwnd, None, int(x), int(y), int(w or 0), int(hh or 0), flags)
        if not h:
            return False
    return bool(_u32.EndDeferWindowPos(h))


def client_animations_enabled() -> bool:
    """Windows' "Show animations in Windows" setting (True when it cannot be read)."""
    if not IS_WINDOWS:
        return True
    on = wintypes.BOOL(1)
    if not _u32.SystemParametersInfoW(_SPI_GETCLIENTAREAANIMATION, 0, ctypes.byref(on), 0):
        return True
    return bool(on.value)
